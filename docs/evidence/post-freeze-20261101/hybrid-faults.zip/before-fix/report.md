# TEST-18 offline fault report

Overall: **FAIL**

Real AsyncDetector/HybridDetector/HybridFrameDetector/SkeletonStack with synthetic sensor/backend inputs; no HTTP or live admission.

{'executed': 216, 'passed': 204, 'failed': 12, 'blocked_combinations': 0}

## Executed fixture cases

| Profile | Behaviour | Track | Fault | Result | Failed checks |
|---|---|---|---|---|---|
| remote | cruise | False | missing_depth | PASS |  |
| remote | cruise | False | invalid_depth | PASS |  |
| remote | cruise | False | missing_capture_clock | PASS |  |
| remote | cruise | False | stale_capture | PASS |  |
| remote | cruise | False | old_sim_frame | PASS |  |
| remote | cruise | False | duplicate_frame | PASS |  |
| remote | cruise | False | foreign_observation | PASS |  |
| remote | cruise | False | old_session_result | PASS |  |
| remote | cruise | False | wrong_result_frame | PASS |  |
| remote | cruise | False | wrong_result_source | FAIL | fault_full_brake, persistent_fault_full_brake |
| remote | cruise | False | detector_exception | PASS |  |
| remote | cruise | False | deadline_miss | PASS |  |
| remote | cruise | False | generation_restart | PASS |  |
| remote | cruise | False | missing_track_id | PASS |  |
| remote | cruise | False | invalid_state | PASS |  |
| remote | cruise | False | controller_exception | PASS |  |
| remote | cruise | False | controller_delay | PASS |  |
| remote | cruise | False | invalid_command | PASS |  |
| remote | cruise | True | missing_depth | PASS |  |
| remote | cruise | True | invalid_depth | PASS |  |
| remote | cruise | True | missing_capture_clock | PASS |  |
| remote | cruise | True | stale_capture | PASS |  |
| remote | cruise | True | old_sim_frame | PASS |  |
| remote | cruise | True | duplicate_frame | PASS |  |
| remote | cruise | True | foreign_observation | PASS |  |
| remote | cruise | True | old_session_result | PASS |  |
| remote | cruise | True | wrong_result_frame | PASS |  |
| remote | cruise | True | wrong_result_source | FAIL | fault_full_brake, persistent_fault_full_brake |
| remote | cruise | True | detector_exception | PASS |  |
| remote | cruise | True | deadline_miss | PASS |  |
| remote | cruise | True | generation_restart | PASS |  |
| remote | cruise | True | missing_track_id | PASS |  |
| remote | cruise | True | invalid_state | PASS |  |
| remote | cruise | True | controller_exception | PASS |  |
| remote | cruise | True | controller_delay | PASS |  |
| remote | cruise | True | invalid_command | PASS |  |
| remote | approach | False | missing_depth | PASS |  |
| remote | approach | False | invalid_depth | PASS |  |
| remote | approach | False | missing_capture_clock | PASS |  |
| remote | approach | False | stale_capture | PASS |  |
| remote | approach | False | old_sim_frame | PASS |  |
| remote | approach | False | duplicate_frame | PASS |  |
| remote | approach | False | foreign_observation | PASS |  |
| remote | approach | False | old_session_result | PASS |  |
| remote | approach | False | wrong_result_frame | PASS |  |
| remote | approach | False | wrong_result_source | FAIL | fault_full_brake, persistent_fault_full_brake |
| remote | approach | False | detector_exception | PASS |  |
| remote | approach | False | deadline_miss | PASS |  |
| remote | approach | False | generation_restart | PASS |  |
| remote | approach | False | missing_track_id | PASS |  |
| remote | approach | False | invalid_state | PASS |  |
| remote | approach | False | controller_exception | PASS |  |
| remote | approach | False | controller_delay | PASS |  |
| remote | approach | False | invalid_command | PASS |  |
| remote | approach | True | missing_depth | PASS |  |
| remote | approach | True | invalid_depth | PASS |  |
| remote | approach | True | missing_capture_clock | PASS |  |
| remote | approach | True | stale_capture | PASS |  |
| remote | approach | True | old_sim_frame | PASS |  |
| remote | approach | True | duplicate_frame | PASS |  |
| remote | approach | True | foreign_observation | PASS |  |
| remote | approach | True | old_session_result | PASS |  |
| remote | approach | True | wrong_result_frame | PASS |  |
| remote | approach | True | wrong_result_source | FAIL | fault_full_brake, persistent_fault_full_brake |
| remote | approach | True | detector_exception | PASS |  |
| remote | approach | True | deadline_miss | PASS |  |
| remote | approach | True | generation_restart | PASS |  |
| remote | approach | True | missing_track_id | PASS |  |
| remote | approach | True | invalid_state | PASS |  |
| remote | approach | True | controller_exception | PASS |  |
| remote | approach | True | controller_delay | PASS |  |
| remote | approach | True | invalid_command | PASS |  |
| remote | hold | False | missing_depth | PASS |  |
| remote | hold | False | invalid_depth | PASS |  |
| remote | hold | False | missing_capture_clock | PASS |  |
| remote | hold | False | stale_capture | PASS |  |
| remote | hold | False | old_sim_frame | PASS |  |
| remote | hold | False | duplicate_frame | PASS |  |
| remote | hold | False | foreign_observation | PASS |  |
| remote | hold | False | old_session_result | PASS |  |
| remote | hold | False | wrong_result_frame | PASS |  |
| remote | hold | False | wrong_result_source | FAIL | fault_cannot_advance_clearance |
| remote | hold | False | detector_exception | PASS |  |
| remote | hold | False | deadline_miss | PASS |  |
| remote | hold | False | generation_restart | PASS |  |
| remote | hold | False | missing_track_id | PASS |  |
| remote | hold | False | invalid_state | PASS |  |
| remote | hold | False | controller_exception | PASS |  |
| remote | hold | False | controller_delay | PASS |  |
| remote | hold | False | invalid_command | PASS |  |
| remote | hold | True | missing_depth | PASS |  |
| remote | hold | True | invalid_depth | PASS |  |
| remote | hold | True | missing_capture_clock | PASS |  |
| remote | hold | True | stale_capture | PASS |  |
| remote | hold | True | old_sim_frame | PASS |  |
| remote | hold | True | duplicate_frame | PASS |  |
| remote | hold | True | foreign_observation | PASS |  |
| remote | hold | True | old_session_result | PASS |  |
| remote | hold | True | wrong_result_frame | PASS |  |
| remote | hold | True | wrong_result_source | FAIL | fault_cannot_advance_clearance |
| remote | hold | True | detector_exception | PASS |  |
| remote | hold | True | deadline_miss | PASS |  |
| remote | hold | True | generation_restart | PASS |  |
| remote | hold | True | missing_track_id | PASS |  |
| remote | hold | True | invalid_state | PASS |  |
| remote | hold | True | controller_exception | PASS |  |
| remote | hold | True | controller_delay | PASS |  |
| remote | hold | True | invalid_command | PASS |  |
| hybrid | cruise | False | missing_depth | PASS |  |
| hybrid | cruise | False | invalid_depth | PASS |  |
| hybrid | cruise | False | missing_capture_clock | PASS |  |
| hybrid | cruise | False | stale_capture | PASS |  |
| hybrid | cruise | False | old_sim_frame | PASS |  |
| hybrid | cruise | False | duplicate_frame | PASS |  |
| hybrid | cruise | False | foreign_observation | PASS |  |
| hybrid | cruise | False | old_session_result | PASS |  |
| hybrid | cruise | False | wrong_result_frame | PASS |  |
| hybrid | cruise | False | wrong_result_source | FAIL | fault_full_brake, persistent_fault_full_brake |
| hybrid | cruise | False | detector_exception | PASS |  |
| hybrid | cruise | False | deadline_miss | PASS |  |
| hybrid | cruise | False | generation_restart | PASS |  |
| hybrid | cruise | False | missing_track_id | PASS |  |
| hybrid | cruise | False | invalid_state | PASS |  |
| hybrid | cruise | False | controller_exception | PASS |  |
| hybrid | cruise | False | controller_delay | PASS |  |
| hybrid | cruise | False | invalid_command | PASS |  |
| hybrid | cruise | True | missing_depth | PASS |  |
| hybrid | cruise | True | invalid_depth | PASS |  |
| hybrid | cruise | True | missing_capture_clock | PASS |  |
| hybrid | cruise | True | stale_capture | PASS |  |
| hybrid | cruise | True | old_sim_frame | PASS |  |
| hybrid | cruise | True | duplicate_frame | PASS |  |
| hybrid | cruise | True | foreign_observation | PASS |  |
| hybrid | cruise | True | old_session_result | PASS |  |
| hybrid | cruise | True | wrong_result_frame | PASS |  |
| hybrid | cruise | True | wrong_result_source | FAIL | fault_full_brake, persistent_fault_full_brake |
| hybrid | cruise | True | detector_exception | PASS |  |
| hybrid | cruise | True | deadline_miss | PASS |  |
| hybrid | cruise | True | generation_restart | PASS |  |
| hybrid | cruise | True | missing_track_id | PASS |  |
| hybrid | cruise | True | invalid_state | PASS |  |
| hybrid | cruise | True | controller_exception | PASS |  |
| hybrid | cruise | True | controller_delay | PASS |  |
| hybrid | cruise | True | invalid_command | PASS |  |
| hybrid | approach | False | missing_depth | PASS |  |
| hybrid | approach | False | invalid_depth | PASS |  |
| hybrid | approach | False | missing_capture_clock | PASS |  |
| hybrid | approach | False | stale_capture | PASS |  |
| hybrid | approach | False | old_sim_frame | PASS |  |
| hybrid | approach | False | duplicate_frame | PASS |  |
| hybrid | approach | False | foreign_observation | PASS |  |
| hybrid | approach | False | old_session_result | PASS |  |
| hybrid | approach | False | wrong_result_frame | PASS |  |
| hybrid | approach | False | wrong_result_source | FAIL | fault_full_brake, persistent_fault_full_brake |
| hybrid | approach | False | detector_exception | PASS |  |
| hybrid | approach | False | deadline_miss | PASS |  |
| hybrid | approach | False | generation_restart | PASS |  |
| hybrid | approach | False | missing_track_id | PASS |  |
| hybrid | approach | False | invalid_state | PASS |  |
| hybrid | approach | False | controller_exception | PASS |  |
| hybrid | approach | False | controller_delay | PASS |  |
| hybrid | approach | False | invalid_command | PASS |  |
| hybrid | approach | True | missing_depth | PASS |  |
| hybrid | approach | True | invalid_depth | PASS |  |
| hybrid | approach | True | missing_capture_clock | PASS |  |
| hybrid | approach | True | stale_capture | PASS |  |
| hybrid | approach | True | old_sim_frame | PASS |  |
| hybrid | approach | True | duplicate_frame | PASS |  |
| hybrid | approach | True | foreign_observation | PASS |  |
| hybrid | approach | True | old_session_result | PASS |  |
| hybrid | approach | True | wrong_result_frame | PASS |  |
| hybrid | approach | True | wrong_result_source | FAIL | fault_full_brake, persistent_fault_full_brake |
| hybrid | approach | True | detector_exception | PASS |  |
| hybrid | approach | True | deadline_miss | PASS |  |
| hybrid | approach | True | generation_restart | PASS |  |
| hybrid | approach | True | missing_track_id | PASS |  |
| hybrid | approach | True | invalid_state | PASS |  |
| hybrid | approach | True | controller_exception | PASS |  |
| hybrid | approach | True | controller_delay | PASS |  |
| hybrid | approach | True | invalid_command | PASS |  |
| hybrid | hold | False | missing_depth | PASS |  |
| hybrid | hold | False | invalid_depth | PASS |  |
| hybrid | hold | False | missing_capture_clock | PASS |  |
| hybrid | hold | False | stale_capture | PASS |  |
| hybrid | hold | False | old_sim_frame | PASS |  |
| hybrid | hold | False | duplicate_frame | PASS |  |
| hybrid | hold | False | foreign_observation | PASS |  |
| hybrid | hold | False | old_session_result | PASS |  |
| hybrid | hold | False | wrong_result_frame | PASS |  |
| hybrid | hold | False | wrong_result_source | FAIL | fault_cannot_advance_clearance |
| hybrid | hold | False | detector_exception | PASS |  |
| hybrid | hold | False | deadline_miss | PASS |  |
| hybrid | hold | False | generation_restart | PASS |  |
| hybrid | hold | False | missing_track_id | PASS |  |
| hybrid | hold | False | invalid_state | PASS |  |
| hybrid | hold | False | controller_exception | PASS |  |
| hybrid | hold | False | controller_delay | PASS |  |
| hybrid | hold | False | invalid_command | PASS |  |
| hybrid | hold | True | missing_depth | PASS |  |
| hybrid | hold | True | invalid_depth | PASS |  |
| hybrid | hold | True | missing_capture_clock | PASS |  |
| hybrid | hold | True | stale_capture | PASS |  |
| hybrid | hold | True | old_sim_frame | PASS |  |
| hybrid | hold | True | duplicate_frame | PASS |  |
| hybrid | hold | True | foreign_observation | PASS |  |
| hybrid | hold | True | old_session_result | PASS |  |
| hybrid | hold | True | wrong_result_frame | PASS |  |
| hybrid | hold | True | wrong_result_source | FAIL | fault_cannot_advance_clearance |
| hybrid | hold | True | detector_exception | PASS |  |
| hybrid | hold | True | deadline_miss | PASS |  |
| hybrid | hold | True | generation_restart | PASS |  |
| hybrid | hold | True | missing_track_id | PASS |  |
| hybrid | hold | True | invalid_state | PASS |  |
| hybrid | hold | True | controller_exception | PASS |  |
| hybrid | hold | True | controller_delay | PASS |  |
| hybrid | hold | True | invalid_command | PASS |  |

## Blocked combinations

