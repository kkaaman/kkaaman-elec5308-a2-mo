"""Isolate camera rendering without synchronous ticking; not acceptance evidence."""
import json
import math
import time
from pathlib import Path

import carla

client = carla.Client("127.0.0.1", 2000)
client.set_timeout(10)
world = client.load_world("Town10HD_Opt", map_layers=carla.MapLayer.NONE)
vehicle = sensor = None
received = []
try:
    p = json.loads(Path("configs/routes/town10hd_baseline_v1.json").read_text())["spawn_pose"]
    vehicle = world.spawn_actor(world.get_blueprint_library().find("vehicle.tesla.model3"), carla.Transform(carla.Location(x=p["x_m"], y=-p["y_m"], z=p["z_m"]), carla.Rotation(yaw=-math.degrees(p["yaw_rad"]))))
    vehicle.apply_control(carla.VehicleControl(brake=1))
    bp = world.get_blueprint_library().find("sensor.camera.rgb")
    bp.set_attribute("image_size_x", "320")
    bp.set_attribute("image_size_y", "180")
    sensor = world.spawn_actor(bp, carla.Transform(carla.Location(x=1.5,z=2)), attach_to=vehicle)
    sensor.listen(lambda image: received.append((image.frame, image.timestamp, len(image.raw_data))))
    for index in range(30):
        snapshot = world.wait_for_tick(10)
        print(json.dumps({"index": index,"frame":snapshot.frame,"receipts":len(received),"last":received[-1] if received else None}),flush=True)
        time.sleep(0.05)
finally:
    client.set_timeout(2)
    try:
        world.get_settings()
        if sensor is not None:
            sensor.stop()
            sensor.destroy()
        if vehicle is not None:
            vehicle.destroy()
    except Exception as error:
        print("Cleanup unknown:", error,flush=True)
