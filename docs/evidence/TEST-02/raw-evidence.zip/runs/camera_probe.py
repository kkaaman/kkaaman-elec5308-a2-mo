"""Isolate camera rendering and paced synchronous ticks; not acceptance evidence."""
import json
import math
import time
from pathlib import Path

import carla

client = carla.Client("127.0.0.1", 2000)
client.set_timeout(10)
world = client.get_world()
settings = world.get_settings()
original = world.get_settings()
original.synchronous_mode = False
original.fixed_delta_seconds = None
settings.synchronous_mode = True
settings.fixed_delta_seconds = 0.05
world.apply_settings(settings)
world = client.load_world(world.get_map().name.rsplit("/", 1)[-1], reset_settings=False, map_layers=carla.MapLayer.NONE)
vehicle = sensor = None
received = []
try:
    route = json.loads(Path("configs/routes/town10hd_baseline_v1.json").read_text())
    p = route["spawn_pose"]
    vehicle = world.spawn_actor(world.get_blueprint_library().find("vehicle.tesla.model3"), carla.Transform(carla.Location(x=p["x_m"], y=-p["y_m"], z=p["z_m"]), carla.Rotation(yaw=-math.degrees(p["yaw_rad"]))))
    vehicle.apply_control(carla.VehicleControl(brake=1))
    for _ in range(20):
        world.tick(10)
        time.sleep(0.05)
    bp = world.get_blueprint_library().find("sensor.camera.rgb")
    bp.set_attribute("image_size_x", "320")
    bp.set_attribute("image_size_y", "180")
    sensor = world.spawn_actor(bp, carla.Transform(carla.Location(x=1.5,z=2)), attach_to=vehicle)
    sensor.listen(lambda image: received.append((image.frame, image.timestamp, len(image.raw_data))))
    for index in range(40):
        frame = world.tick(10)
        time.sleep(0.05)
        print(json.dumps({"index": index, "frame":frame,"receipts":len(received),"last":received[-1] if received else None}),flush=True)
finally:
    client.set_timeout(2)
    try:
        world.get_settings()
        if sensor is not None:
            sensor.stop()
            sensor.destroy()
        if vehicle is not None:
            vehicle.destroy()
        world.apply_settings(original)
    except Exception as error:
        print("Cleanup unknown:", error,flush=True)
