"""Create an isolated CARLA 0.9.16 executable copy with a verified task-target fix.

The original executable is never modified. The change corresponds to replacing
AsyncTask(ENamedThreads::HighTaskPriority, ...) with
AsyncTask(ENamedThreads::AnyNormalThreadHiPriTask, ...) in PixelReader.cpp.
Only the exact diagnosed Windows build and instruction bytes are accepted.
"""

import hashlib
import json
from pathlib import Path
import struct


root = Path(__file__).resolve().parent
original = Path("D:/CARLA_0.9.16/CarlaUE4/Binaries/Win64/CarlaUE4-Win64-Shipping.exe")
destination = root / "CarlaUE4-Win64-RgbFix.exe"
data = original.read_bytes()
digest = hashlib.sha256(data).hexdigest()
if digest != "ba05ec36f7f0b548b266865ea2787a1dc5a028e298ebefcf0c49196ac629c4d3":
    raise RuntimeError("Only the diagnosed CARLA executable SHA256 is supported")
pe = struct.unpack_from("<I", data, 0x3C)[0]
if data[pe:pe + 4] != b"PE\0\0":
    raise RuntimeError("Not a PE image")
machine, sections = struct.unpack_from("<HH", data, pe + 4)
optional_size = struct.unpack_from("<H", data, pe + 20)[0]
if machine != 0x8664 or len(data) != 91477504:
    raise RuntimeError("Unexpected executable architecture or size")
rva = 0x8945B8
section_start = pe + 24 + optional_size
offset = None
for index in range(sections):
    section = section_start + 40 * index
    name, virtual_size, virtual_address, raw_size, raw_pointer = struct.unpack_from(
        "<8sIIII", data, section,
    )
    if virtual_address <= rva < virtual_address + raw_size:
        if name.rstrip(b"\0") != b".text":
            raise RuntimeError("Patch target is not in the code section")
        offset = raw_pointer + rva - virtual_address
        break
if offset is None:
    raise RuntimeError("Patch instruction was not found")
before = bytes.fromhex("b9 00 02 00 00 e8 2e c1 7c 00")
after = bytes.fromhex("b9 ff 02 00 00 e8 2e c1 7c 00")
if data[offset:offset + len(before)] != before:
    raise RuntimeError("Build-specific instruction guard failed")
modified = data[:offset] + after + data[offset + len(after):]
changes = [i for i, (old, new) in enumerate(zip(data, modified)) if old != new]
if changes != [offset + 1]:
    raise RuntimeError("Unexpected executable changes")
with destination.open("xb") as file:
    file.write(modified)
if hashlib.sha256(original.read_bytes()).hexdigest() != digest:
    raise RuntimeError("Original executable changed")
report = {
    "scope": "Diagnostic executable copy; original installation is unchanged",
    "source": str(original), "destination": str(destination),
    "original_sha256": digest,
    "modified_sha256": hashlib.sha256(modified).hexdigest(),
    "file_offset": hex(offset), "instruction_rva": hex(rva),
    "before": before.hex(), "after": after.hex(), "changed_bytes": 1,
    "source_equivalent": "PixelReader.cpp: AsyncTask(ENamedThreads::AnyNormalThreadHiPriTask, ...)",
    "reason": "HighTaskPriority alone selected StatsThread in the shipped build; GPU readback busy-wait blocked FStats::AdvanceFrame",
    "status": "EXPERIMENTAL_PENDING_CAMERA_VALIDATION",
}
(root / "rgb-fix-build.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report, indent=2))
