"""Independent, bounded RGB probe. This is diagnostic evidence, not S0 acceptance."""

import argparse
from collections import deque
import hashlib
import json
from pathlib import Path
import threading
import time
import traceback

import carla


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--frames", type=int, default=300)
    parser.add_argument("--width", type=int, default=320)
    parser.add_argument("--height", type=int, default=180)
    parser.add_argument("--sensor-tick", type=float, default=0.0)
    parser.add_argument("--pace", type=float, default=0.05)
    parser.add_argument("--no-reload", action="store_true")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    client = carla.Client("127.0.0.1", 2000)
    client.set_timeout(10)
    world = client.get_world()
    original = world.get_settings()
    if original.synchronous_mode:
        raise RuntimeError("An existing synchronous owner is present")
    foreign = [a.id for a in world.get_actors()
               if a.type_id.startswith(("vehicle.", "sensor.", "walker."))]
    if foreign:
        raise RuntimeError(f"Existing dynamic actors are present: {foreign}")
    report = {
        "status": "INCOMPLETE", "scope": "Independent RGB capture only",
        "width": args.width, "height": args.height,
        "sensor_tick": args.sensor_tick, "requested_ticks": args.frames,
        "pace_s": args.pace, "reload_world": not args.no_reload,
        "receipts": 0, "completed_ticks": 0, "cleanup_ok": False,
    }
    receipts = deque(maxlen=32)
    lock = threading.Lock()
    errors = []
    sensor = vehicle = None
    stage = "configure_world"
    journal = (args.output / "progress.jsonl").open("w", encoding="utf-8", buffering=1)

    def note(kind, **fields):
        journal.write(json.dumps({"kind": kind, "monotonic_s": time.monotonic(),
                                  **fields}) + "\n")

    def receive(image):
        received = time.monotonic()
        with lock:
            report["receipts"] += 1
            receipts.append((image, received))

    try:
        report["server"] = client.get_server_version()
        report["client"] = client.get_client_version()
        settings = world.get_settings()
        settings.synchronous_mode = True
        settings.fixed_delta_seconds = 0.05
        settings.no_rendering_mode = False
        settings.substepping = True
        settings.max_substep_delta_time = 0.01
        settings.max_substeps = 10
        world.apply_settings(settings)
        if not args.no_reload:
            stage = "reload_world"
            note(stage)
            world = client.load_world(
                world.get_map().name.rsplit("/", 1)[-1],
                reset_settings=False, map_layers=carla.MapLayer.NONE,
            )
        report["map"] = world.get_map().name
        stage = "spawn_vehicle"
        spawn = world.get_map().get_spawn_points()[0]
        vehicle = world.spawn_actor(
            world.get_blueprint_library().find("vehicle.tesla.model3"), spawn,
        )
        vehicle.apply_control(carla.VehicleControl(brake=1.0, hand_brake=True))
        stage = "settle_vehicle"
        for _ in range(20):
            world.tick(10)
        stage = "spawn_camera"
        bp = world.get_blueprint_library().find("sensor.camera.rgb")
        for key, value in {
            "image_size_x": args.width, "image_size_y": args.height,
            "sensor_tick": args.sensor_tick, "fov": 90,
            "enable_postprocess_effects": "false",
        }.items():
            bp.set_attribute(key, str(value))
        sensor = world.spawn_actor(
            bp, carla.Transform(carla.Location(x=1.5, z=2)),
            attach_to=vehicle, attachment_type=carla.AttachmentType.Rigid,
        )
        sensor.listen(receive)
        last_image_frame = -1
        stage = "camera_tick"
        for index in range(args.frames):
            note("tick_started", index=index, receipts=report["receipts"])
            started = time.monotonic()
            frame = world.tick(10)
            elapsed = time.monotonic() - started
            report["completed_ticks"] += 1
            if args.pace:
                time.sleep(args.pace)
            with lock:
                latest = receipts[-1] if receipts else None
            fields = {"index": index, "frame": frame, "tick_wall_s": elapsed,
                      "receipts": report["receipts"]}
            if latest is not None:
                image, received = latest
                expected = args.width * args.height * 4
                if (image.width, image.height) != (args.width, args.height):
                    raise RuntimeError("Camera dimensions changed")
                if len(image.raw_data) != expected:
                    raise RuntimeError("Image buffer size is invalid")
                fields.update(image_frame=image.frame, image_time_s=image.timestamp,
                              received_monotonic_s=received, bytes=expected)
                if "first_image_sha256" not in report:
                    report["first_image_sha256"] = hashlib.sha256(image.raw_data).hexdigest()
                    image.save_to_disk(str(args.output / "first-image.png"))
                if image.frame < last_image_frame:
                    raise RuntimeError("Camera frame order regressed")
                last_image_frame = image.frame
            note("tick_completed", **fields)
            if index % 20 == 0:
                print(json.dumps(fields), flush=True)
        minimum_receipts = max(10, int(args.frames * (
            0.05 / max(0.05, args.sensor_tick))) - 10)
        if report["receipts"] < minimum_receipts:
            raise RuntimeError(f"Too few camera frames: {report['receipts']}")
        report["status"] = "PASS"
    except Exception as error:
        report.update(status="FAIL", failure_stage=stage,
                      failure=f"{type(error).__name__}: {error}",
                      traceback=traceback.format_exc())
    finally:
        client.set_timeout(2)
        reachable = True
        try:
            world.get_settings()
        except Exception as error:
            reachable = False
            errors.append(f"Server health check failed: {error}")
        if reachable:
            for actor in (sensor, vehicle):
                if actor is not None:
                    try:
                        if actor is sensor:
                            actor.stop()
                        if not actor.destroy():
                            errors.append(f"Actor destruction failed: {actor.id}")
                    except Exception as error:
                        errors.append(f"Actor cleanup failed: {error}")
            try:
                world.apply_settings(original)
                restored = world.get_settings()
                if (restored.synchronous_mode != original.synchronous_mode or
                        restored.fixed_delta_seconds != original.fixed_delta_seconds or
                        restored.no_rendering_mode != original.no_rendering_mode):
                    errors.append("World settings were not restored")
                remaining = [a.id for a in world.get_actors()
                             if a.type_id.startswith(("vehicle.", "sensor."))]
                if remaining:
                    errors.append(f"Dynamic actors remain: {remaining}")
            except Exception as error:
                errors.append(f"World cleanup failed: {error}")
        report["cleanup_ok"] = not errors
        report["cleanup_errors"] = errors
        report["last_stage"] = stage
        if errors:
            report["status"] = "FAIL"
        (args.output / "report.json").write_text(
            json.dumps(report, indent=2) + "\n", encoding="utf-8",
        )
        journal.close()
    print(json.dumps(report, indent=2), flush=True)
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
