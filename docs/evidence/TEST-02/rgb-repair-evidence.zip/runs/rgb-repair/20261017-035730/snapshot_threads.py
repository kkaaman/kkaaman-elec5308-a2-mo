"""Read thread stacks from the owned CARLA process using local debug symbols."""

import argparse
import ctypes as C
from ctypes import wintypes as W
import json
from pathlib import Path
import struct


class ThreadEntry(C.Structure):
    _fields_ = [("size", W.DWORD), ("usage", W.DWORD),
                ("tid", W.DWORD), ("pid", W.DWORD),
                ("priority", W.LONG), ("delta", W.LONG), ("flags", W.DWORD)]


class Address(C.Structure):
    _fields_ = [("offset", C.c_ulonglong), ("segment", W.WORD), ("mode", W.DWORD)]


class Frame(C.Structure):
    _fields_ = [
        ("pc", Address), ("ret", Address), ("frame", Address),
        ("stack", Address), ("bstore", Address), ("function", C.c_void_p),
        ("params", C.c_ulonglong * 4), ("far", W.BOOL), ("virtual", W.BOOL),
        ("reserved", C.c_ulonglong * 3), ("kdhelp_storage", C.c_byte * 512),
    ]


class Symbol(C.Structure):
    _fields_ = [
        ("size", W.ULONG), ("type_index", W.ULONG),
        ("reserved", C.c_ulonglong * 2), ("index", W.ULONG), ("symbol_size", W.ULONG),
        ("module_base", C.c_ulonglong), ("flags", W.ULONG),
        ("value", C.c_ulonglong), ("address", C.c_ulonglong),
        ("register", W.ULONG), ("scope", W.ULONG), ("tag", W.ULONG),
        ("name_length", W.ULONG), ("max_name_length", W.ULONG), ("name", C.c_char * 1),
    ]


def bind(library, name, result, *arguments):
    function = getattr(library, name)
    function.restype = result
    function.argtypes = arguments
    return function


parser = argparse.ArgumentParser()
parser.add_argument("--pid", type=int, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
k = C.WinDLL("kernel32", use_last_error=True)
d = C.WinDLL("dbghelp", use_last_error=True)
p = C.WinDLL("psapi", use_last_error=True)
open_process = bind(k, "OpenProcess", W.HANDLE, W.DWORD, W.BOOL, W.DWORD)
close = bind(k, "CloseHandle", W.BOOL, W.HANDLE)
query_name = bind(k, "QueryFullProcessImageNameW", W.BOOL, W.HANDLE, W.DWORD,
                  W.LPWSTR, C.POINTER(W.DWORD))
snapshot = bind(k, "CreateToolhelp32Snapshot", W.HANDLE, W.DWORD, W.DWORD)
first_thread = bind(k, "Thread32First", W.BOOL, W.HANDLE, C.POINTER(ThreadEntry))
next_thread = bind(k, "Thread32Next", W.BOOL, W.HANDLE, C.POINTER(ThreadEntry))
open_thread = bind(k, "OpenThread", W.HANDLE, W.DWORD, W.BOOL, W.DWORD)
suspend = bind(k, "SuspendThread", W.DWORD, W.HANDLE)
resume = bind(k, "ResumeThread", W.DWORD, W.HANDLE)
get_context = bind(k, "GetThreadContext", W.BOOL, W.HANDLE, C.c_void_p)
get_description = bind(k, "GetThreadDescription", W.LONG, W.HANDLE, C.POINTER(W.LPWSTR))
local_free = bind(k, "LocalFree", C.c_void_p, C.c_void_p)
module_name = bind(p, "GetModuleFileNameExW", W.DWORD, W.HANDLE, W.HMODULE,
                   W.LPWSTR, W.DWORD)
sym_options = bind(d, "SymSetOptions", W.DWORD, W.DWORD)
sym_init = bind(d, "SymInitializeW", W.BOOL, W.HANDLE, W.LPCWSTR, W.BOOL)
sym_cleanup = bind(d, "SymCleanup", W.BOOL, W.HANDLE)
module_base = bind(d, "SymGetModuleBase64", C.c_ulonglong, W.HANDLE, C.c_ulonglong)
sym_address = bind(d, "SymFromAddr", W.BOOL, W.HANDLE, C.c_ulonglong,
                   C.POINTER(C.c_ulonglong), C.POINTER(Symbol))
walk = bind(d, "StackWalk64", W.BOOL, W.DWORD, W.HANDLE, W.HANDLE,
            C.POINTER(Frame), C.c_void_p, C.c_void_p, C.c_void_p, C.c_void_p, C.c_void_p)
process = open_process(0x410, False, args.pid)
if not process:
    raise C.WinError(C.get_last_error())
name_buffer = C.create_unicode_buffer(32768)
name_size = W.DWORD(len(name_buffer))
if not query_name(process, 0, name_buffer, C.byref(name_size)):
    raise C.WinError(C.get_last_error())
image = Path(name_buffer.value)
if image.name.lower() not in {"carlaue4-win64-shipping.exe", "carlaue4-win64-rgbfix.exe"}:
    raise RuntimeError("Refusing to inspect a process other than CARLA")
sym_options(0x2 | 0x4 | 0x200 | 0x80000)
if not sym_init(process, str(image.parent) + ";C:/Windows/System32", True):
    raise C.WinError(C.get_last_error())
result = {"pid": args.pid, "executable": str(image), "threads": []}


def describe(address):
    entry = {"address": hex(address)}
    base = module_base(process, address)
    if base:
        buffer = C.create_unicode_buffer(32768)
        module_name(process, base, buffer, len(buffer))
        entry.update(module=Path(buffer.value).name, offset=hex(address - base))
    memory = C.create_string_buffer(C.sizeof(Symbol) + 4096)
    symbol = C.cast(memory, C.POINTER(Symbol))
    symbol.contents.size = C.sizeof(Symbol)
    symbol.contents.max_name_length = 4096
    displacement = C.c_ulonglong()
    if sym_address(process, address, C.byref(displacement), symbol):
        entry["symbol"] = C.string_at(
            C.addressof(memory) + Symbol.name.offset, symbol.contents.name_length,
        ).decode("utf-8", errors="replace")
        entry["displacement"] = displacement.value
    return entry


try:
    threads = snapshot(4, 0)
    if threads == C.c_void_p(-1).value:
        raise C.WinError(C.get_last_error())
    thread_ids = []
    try:
        entry = ThreadEntry()
        entry.size = C.sizeof(entry)
        valid = first_thread(threads, C.byref(entry))
        while valid:
            if entry.pid == args.pid:
                thread_ids.append(entry.tid)
            entry.size = C.sizeof(entry)
            valid = next_thread(threads, C.byref(entry))
    finally:
        close(threads)
    print(f"Inspecting {len(thread_ids)} CARLA threads.", flush=True)
    for tid in thread_ids:
        thread = open_thread(0x2 | 0x8 | 0x40, False, tid)
        item = {"tid": tid, "frames": []}
        if not thread:
            item["error"] = f"OpenThread: {C.get_last_error()}"
            result["threads"].append(item)
            continue
        try:
            description = W.LPWSTR()
            if get_description(thread, C.byref(description)) == 0 and description:
                item["name"] = description.value
                local_free(C.cast(description, C.c_void_p))
            raw = C.create_string_buffer(1232 + 16)
            address = (C.addressof(raw) + 15) & ~15
            context = C.c_void_p(address)
            C.c_uint32.from_address(address + 48).value = 0x10000B
            if suspend(thread) == 0xFFFFFFFF:
                raise C.WinError(C.get_last_error())
            try:
                if not get_context(thread, context):
                    raise C.WinError(C.get_last_error())
            finally:
                resume(thread)
            # Resume immediately; symbol loading never holds a target thread suspended.
            data = C.string_at(address, 1232)
            rsp = struct.unpack_from("<Q", data, 152)[0]
            rbp = struct.unpack_from("<Q", data, 160)[0]
            rip = struct.unpack_from("<Q", data, 248)[0]
            frame = Frame()
            frame.pc.offset, frame.pc.mode = rip, 3
            frame.stack.offset, frame.stack.mode = rsp, 3
            frame.frame.offset, frame.frame.mode = rbp, 3
            item["frames"].append(describe(rip))
            seen = {rip}
            for _ in range(40):
                if not walk(0x8664, process, thread, C.byref(frame), context, None,
                            C.cast(d.SymFunctionTableAccess64, C.c_void_p),
                            C.cast(d.SymGetModuleBase64, C.c_void_p), None):
                    break
                pc = frame.pc.offset
                if not pc:
                    break
                if pc not in seen:
                    item["frames"].append(describe(pc))
                    seen.add(pc)
            result["threads"].append(item)
        except Exception as error:
            item["error"] = str(error)
            result["threads"].append(item)
        finally:
            close(thread)
        args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    for item in result["threads"]:
        names = [frame.get("symbol", frame.get("module", "?")) for frame in item["frames"]]
        if any(any(word in name for word in ("PixelReader", "Readback", "RenderQuery",
                                             "D3D11", "Fence", "GameEngine::Tick"))
               for name in names):
            print(json.dumps({"tid": item["tid"], "name": item.get("name"), "stack": names}),
                  flush=True)
finally:
    sym_cleanup(process)
    close(process)
