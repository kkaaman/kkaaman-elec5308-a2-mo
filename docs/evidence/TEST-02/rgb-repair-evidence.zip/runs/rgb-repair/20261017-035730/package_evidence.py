"""Audit retained live artifacts and publish a source-only evidence bundle."""
import csv
import hashlib
import json
import shutil
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
DOCS = REPO / "docs/evidence/TEST-02"


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")


def relative(path):
    return path.relative_to(REPO).as_posix()


def suite(name):
    folder = ROOT / name
    summary = read(folder / "summary.json")
    assert summary["status"] == "PASS" and summary["passed_runs"] == 5
    runs = []
    episodes = []
    for run in sorted(folder.glob("run-*")):
        result, manifest = read(run / "summary.json"), read(run / "manifest.json")
        assert result["status"] == "PASS" and result["completed"]
        assert result["route_install_count"] == 1 and result["cleanup_ok"]
        assert manifest["formal_acceptance"] and manifest["source_unchanged_during_run"]
        assert manifest["effective_config"]["runtime"]["rgb_enabled"]
        assert manifest["world_episode_id_before"] != manifest["world_episode_id_after"]
        episodes.append(manifest["world_episode_id_after"])
        runs.append({"folder": relative(run), "status": result["status"],
                     "completed": result["completed"], "cleanup_ok": result["cleanup_ok"],
                     "route_install_count": result["route_install_count"],
                     "samples": result["sample_count"], "camera_receipts": manifest["camera_receipts"],
                     "world_episode_id": manifest["world_episode_id_after"],
                     "source_bundle_sha256": manifest["execution_provenance"]["source_bundle_sha256"]})
    assert len(runs) == 5 and len(set(episodes)) == 5
    return {"folder": relative(folder), "status": summary["status"],
            "required_runs": 5, "passed_runs": 5, "failed_runs": summary["failed_runs"],
            "worst_run_metrics": summary["worst_run_metrics"],
            "frozen_provenance": summary["frozen_provenance"], "runs": runs}


def hold(case):
    folder = ROOT / f"guard-hold-{case}" / "run-01"
    summary = read(folder / "summary.json")
    events = read(folder / "events.json")
    start = next(e["step_index"] for e in events if e["kind"] == "hold_started")
    release = next(e["step_index"] for e in events if e["kind"] == "hold_released")
    finish = next(e["step_index"] for e in events if e["kind"] == "mission_finished")
    with (folder / "samples.csv").open(newline="", encoding="utf-8") as file:
        samples = list(csv.DictReader(file))
    # Lifecycle updates are one-based; CSV records start with the first update.
    held = samples[start - 1:release - 1]
    checks = {"completed": summary["completed"], "cleanup_ok": summary["cleanup_ok"],
              "one_route_installation": summary["route_install_count"] == 1,
              "hold_reached_zero_speed": min(float(s["speed_mps"]) for s in held) <= 0.1,
              "hold_zero_throttle": all(float(s["throttle"]) == 0 for s in held),
              "no_finished_during_hold": all(s["status"] == "stopping" for s in held),
              "finished_after_release": finish >= release}
    assert len(held) == 40 and all(checks.values())
    return {"case": case, "folder": relative(folder), "lifecycle_status": "PASS",
            "s0_status": summary["status"], "failed_metrics": summary["failed_metrics"],
            "hold_samples": len(held), "hold_duration_simulation_s": 2,
            "start_step": start, "release_step": release, "finish_step": finish, **checks}


def main():
    primary = suite("packaged-acceptance")
    stability = [suite(name) for name in ("guard-acceptance-a", "guard-acceptance-b")]
    holds = [hold(case) for case in ("straight", "curve", "near-goal")]
    write(ROOT / "guard-hold-checks.json", holds)
    preliminary = []
    for folder in sorted(ROOT.iterdir()):
        if not folder.is_dir() or folder.name in {"runtime-guard", "verification", "patch-test-temp", "__pycache__"}:
            continue
        if (folder / "summary.json").is_file():
            summary = read(folder / "summary.json")
            preliminary.append({"folder": relative(folder),
                                **{k: summary[k] for k in ("status", "recorded_runs", "passed_runs", "failed_runs", "failures") if k in summary},
                                "runs": [{"folder": relative(run), **{k: read(run / "summary.json").get(k) for k in
                                          ("status", "completed", "failure_reason", "cleanup_ok", "sample_count", "failed_metrics")}}
                                         for run in sorted(folder.glob("run-*")) if (run / "summary.json").exists()]})
        elif (folder / "report.json").is_file():
            preliminary.append({"folder": relative(folder), "probe": read(folder / "report.json")})
    junit = ET.parse(ROOT / "full-regression.xml").getroot()
    assert not junit.findall(".//failure") and not junit.findall(".//error")
    legacy = [case for case in junit.iter("testcase") if case.get("classname", "").startswith(
        ("tests.navigation_control.", "tests.test_carla_adapter", "tests.test_lane_path", "tests.test_perception", "tests.test_traffic_perception"))]
    assert "653 passed, 1 skipped" in (ROOT / "verification/pytest.log").read_text(encoding="utf-8-sig")
    assert "All checks passed" in (ROOT / "verification/ruff.log").read_text(encoding="utf-8-sig")
    assert "Imported 64 core modules" in (ROOT / "verification/import-boundary.log").read_text(encoding="utf-8-sig")
    assert "build succeeded." in (ROOT / "verification/sphinx.log").read_text(encoding="utf-8-sig")
    build = read(REPO / "runs/carla-rgb-runtime/rgb-repair-runtime.json")
    report = {
        "date": "2026-10-17", "formal_s0_acceptance": "PASS", "required_formal_runs": 5,
        "primary_suite": primary, "additional_stability_suites": stability,
        "same_server_session_sequence": ["guard-acceptance-a", "guard-hold-near-goal", "guard-hold-straight", "guard-hold-curve", "guard-acceptance-b"],
        "total_passing_runs_on_final_profile": 15,
        "scope": "Course-authorized ego-truth navigation with real RGB capture; not obstacle perception acceptance or G1 reviewer approval",
        "minimum_machine": {"cpu": "Ryzen 5 5600H", "gpu": "RTX 3050 Laptop 4 GB", "ram_gb": 16,
                            "driver": "617.42", "os": "Windows 10 19045", "carla": "0.9.16"},
        "repair": {"task_routing": "Compiled RGB readback target 0x200 selected StatsThread; changed to AnyNormalThreadHiPriTask 0x2ff",
                   "d3d11_protection": "Source-built application-local D3D11CreateDevice guard enables immediate-context multithread protection and removes the single-thread-only flag",
                   "original_installation_unchanged": True, "runtime_manifest": build,
                   "core_route_controller_configuration_unchanged": True},
        "capture_probe": read(ROOT / "probe-guard/report.json"),
        "first_image_comparison": "First valid image SHA256 matches the original and task-only server captures",
        "hold_regressions": holds,
        "hold_metric_interpretation": "Straight and curve deliberately inject a stop outside the endpoint and correctly fail false_stops; all lifecycle checks pass. These are separate nonformal regressions.",
        "retained_trials": preliminary,
        "diagnostic_interpretation": [
            "Driver update alone left the deterministic five-frame deadlock unchanged.",
            "Task-only runtime passed an initial five-run suite but later encountered D3D11 0x887A0020; that failed near-goal run remains retained.",
            "RHI threading alone did not fix the intermediate device error: rhi-acceptance-a retains three passing and two failed runs.",
            "Early startup retries reused a failed client and were inconclusive; later readiness checks use a fresh client on every retry.",
            "The final context-protected profile uses plain DX11 with no RHI-thread override, frozen 320x180 RGB and fixed 0.05 s simulation steps."],
        "offline_verification": {"pytest": "653 passed, 1 skipped", "a1_legacy_testcases": len(legacy),
                                 "ruff": "PASS", "simulator_boundary": "PASS: 64 core imports", "sphinx": "PASS: warnings treated as errors"},
        "final_live_cleanup": read(ROOT / "final-live-cleanup.json"),
        "limits": "Validated on the exact hash-guarded Windows package and this machine/profile. Other builds and render backends require separate validation. Native artifacts are generated locally and excluded from Git/evidence ZIP.",
    }
    write(DOCS / "rgb-repair-results.json", report)
    historical = read(DOCS / "results.json")
    historical.update(formal_s0_acceptance="PASS: repaired Windows runtime, frozen RGB-enabled S0 configuration",
                      passing_formal_runs=5, scope=report["scope"],
                      current_rgb_report="rgb-repair-results.json", primary_rgb_suite=primary,
                      additional_rgb_stability_suites=stability,
                      camera_probe_observation="Historical original runtime stalled after five receipts; final repaired runtime passed independent 300-tick probe and complete acceptance")
    write(DOCS / "results.json", historical)
    environment = read(DOCS / "environment.json")
    environment.update(nvidia_driver="617.42", historical_original_nvidia_driver="552.22",
                       graphics_attempts_scope="Historical original/intermediate runtime attempts; see RGB repair report for final passing profile",
                       scope="Minimum-spec hardware, retained historical diagnostics and final RGB acceptance",
                       formal_s0_acceptance="PASS: five frozen RGB-enabled runs on isolated repaired runtime",
                       current_rgb_runtime=build, current_rgb_report="rgb-repair-results.json")
    write(DOCS / "environment.json", environment)
    shutil.copy2(ROOT / "full-regression.xml", DOCS / "rgb-repair-regression.xml")
    shutil.copy2(ROOT / "probe-guard/first-image.png", DOCS / "rgb-first-frame.png")
    write(ROOT / "evidence-audit.json", {"status": "PASS", "passing_final_profile_runs": 15,
                                         "hold_checks": holds, "a1_legacy_testcases": len(legacy)})
    print(json.dumps({"status": "PASS", "formal_runs": 15, "holds": len(holds), "a1_legacy_testcases": len(legacy)}))


def archive():
    # Do not recursively enumerate runtime directories: they contain junctions to large shared assets.
    allowed = {".json", ".jsonl", ".log", ".py", ".cpp", ".def", ".txt", ".patch", ".csv", ".png", ".xml"}
    files = {path for path in ROOT.iterdir() if path.is_file() and path.suffix in allowed}
    for folder in ROOT.iterdir():
        if folder.is_dir() and folder.name.startswith(("probe-", "rgbfix-single", "acceptance-five", "rgb-hold-", "rhi-hold-", "rhi-acceptance-", "guard-hold-", "guard-acceptance-", "packaged-acceptance")):
            files.update(path for path in folder.rglob("*") if path.is_file() and path.suffix in allowed)
    files.update(path for path in (ROOT / "verification").iterdir() if path.is_file() and path.suffix in allowed)
    for folder in (REPO / "runs/manual/driver61742-retest-20261017-034936",):
        files.update(path for path in folder.rglob("*") if path.is_file() and path.suffix in allowed)
    for runtime in (ROOT / "runtime-guard", REPO / "runs/carla-rgb-runtime"):
        for relative_path in ("rgb-repair-runtime.json", "CarlaUE4/Binaries/Win64/carla-d3d11-guard.jsonl"):
            path = runtime / relative_path
            if path.is_file():
                files.add(path)
    files.update(REPO / path for path in (
        "scripts/patch_carla_rgb_readback.py", "tools/carla_rgb_readback/d3d11_guard.cpp",
        "tools/carla_rgb_readback/d3d11_guard.def", "patches/carla-0.9.16-rgb-readback-worker.patch",
        "docs/evidence/TEST-02/rgb-repair-results.json", "tests/unit/test_carla_rgb_patch.py"))
    target = DOCS / "rgb-repair-evidence.zip"
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zip_file:
        for path in sorted(files):
            zip_file.write(path, relative(path))
    with zipfile.ZipFile(target) as zip_file:
        assert zip_file.testzip() is None
        assert all(Path(name).suffix.lower() not in {".exe", ".dll", ".pdb", ".dmp"} for name in zip_file.namelist())
    digest = hashlib.sha256(target.read_bytes()).hexdigest()
    (DOCS / "rgb-repair-evidence.sha256").write_text(f"{digest}  {target.name}\n", encoding="ascii")
    print(json.dumps({"files": len(files), "bytes": target.stat().st_size, "sha256": digest}))


if __name__ == "__main__":
    import sys
    archive() if "--archive" in sys.argv else main()
