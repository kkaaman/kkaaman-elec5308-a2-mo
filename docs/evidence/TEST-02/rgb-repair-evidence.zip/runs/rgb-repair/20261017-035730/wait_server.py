"""Wait for an owned CARLA process without modifying the simulation."""

import argparse
import ctypes
from ctypes import wintypes
import json
from pathlib import Path
import time

import carla


parser = argparse.ArgumentParser()
parser.add_argument("--pid", type=int, required=True)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--timeout", type=float, default=180)
args = parser.parse_args()
kernel = ctypes.WinDLL("kernel32", use_last_error=True)
kernel.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.GetExitCodeProcess.argtypes = (wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD))
kernel.GetExitCodeProcess.restype = wintypes.BOOL
kernel.CloseHandle.argtypes = (wintypes.HANDLE,)
handle = kernel.OpenProcess(0x1000, False, args.pid)
started = time.monotonic()
notice = started
report = None
last_error = None
try:
    while time.monotonic() - started < args.timeout:
        code = wintypes.DWORD()
        if handle and kernel.GetExitCodeProcess(handle, ctypes.byref(code)) and code.value != 259:
            report = {"status": "FAIL", "stage": "startup",
                      "exit_code": code.value, "error": last_error}
            break
        try:
            client = carla.Client("127.0.0.1", 2000)
            client.set_timeout(3)
            version = client.get_server_version()
            world = client.get_world()
            settings = world.get_settings()
            report = {"status": "READY", "server": version,
                      "client": client.get_client_version(),
                      "map": world.get_map().name,
                      "synchronous_mode": settings.synchronous_mode,
                      "no_rendering_mode": settings.no_rendering_mode,
                      "wait_s": time.monotonic() - started}
            break
        except RuntimeError as error:
            last_error = str(error)
            if time.monotonic() - notice > 20:
                print("Waiting for CARLA startup.", flush=True)
                notice = time.monotonic()
            time.sleep(2)
    if report is None:
        report = {"status": "FAIL", "stage": "startup", "error": last_error}
finally:
    if handle:
        kernel.CloseHandle(handle)
args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report), flush=True)
raise SystemExit(0 if report["status"] == "READY" else 1)
