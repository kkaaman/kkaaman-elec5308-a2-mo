"""Resolve local CARLA symbols and source lines without modifying the process."""

import argparse
import ctypes as C
from ctypes import wintypes as W
import json
from pathlib import Path


class Symbol(C.Structure):
    _fields_ = [
        ("size", W.ULONG), ("type_index", W.ULONG),
        ("reserved", C.c_ulonglong * 2), ("index", W.ULONG), ("symbol_size", W.ULONG),
        ("module_base", C.c_ulonglong), ("flags", W.ULONG),
        ("value", C.c_ulonglong), ("address", C.c_ulonglong),
        ("register", W.ULONG), ("scope", W.ULONG), ("tag", W.ULONG),
        ("name_length", W.ULONG), ("max_name_length", W.ULONG), ("name", C.c_char * 1),
    ]


class SourceLine(C.Structure):
    _fields_ = [("size", W.DWORD), ("key", C.c_void_p), ("line", W.DWORD),
                ("file", C.c_char_p), ("address", C.c_ulonglong)]


parser = argparse.ArgumentParser()
parser.add_argument("--pid", type=int, required=True)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--address", type=lambda x:int(x, 0))
args = parser.parse_args()
k = C.WinDLL("kernel32", use_last_error=True)
d = C.WinDLL("dbghelp", use_last_error=True)
k.OpenProcess.argtypes = [W.DWORD, W.BOOL, W.DWORD]
k.OpenProcess.restype = W.HANDLE
k.CloseHandle.argtypes = [W.HANDLE]
d.SymInitializeW.argtypes = [W.HANDLE, W.LPCWSTR, W.BOOL]
d.SymInitializeW.restype = W.BOOL
d.SymSetOptions.argtypes = [W.DWORD]
d.SymGetModuleBase64.argtypes = [W.HANDLE, C.c_ulonglong]
d.SymGetModuleBase64.restype = C.c_ulonglong
d.SymGetLineFromAddr64.argtypes = [W.HANDLE, C.c_ulonglong, C.POINTER(W.DWORD),
                                 C.POINTER(SourceLine)]
d.SymGetLineFromAddr64.restype = W.BOOL
callback_type = C.WINFUNCTYPE(W.BOOL, C.POINTER(Symbol), W.ULONG, C.c_void_p)
d.SymEnumSymbols.argtypes = [W.HANDLE, C.c_ulonglong, C.c_char_p, callback_type, C.c_void_p]
d.SymEnumSymbols.restype = W.BOOL
d.SymCleanup.argtypes = [W.HANDLE]
process = k.OpenProcess(0x410, False, args.pid)
if not process:
    raise C.WinError(C.get_last_error())
d.SymSetOptions(0x2 | 0x4 | 0x10 | 0x200 | 0x80000)
if not d.SymInitializeW(process, "D:/CARLA_0.9.16/CarlaUE4/Binaries/Win64;C:/Windows/System32", True):
    raise C.WinError(C.get_last_error())
result = {"symbols": []}


@callback_type
def callback(pointer, size, context):
    info = pointer.contents
    name = C.string_at(C.addressof(info) + Symbol.name.offset,
                       info.name_length).decode("utf-8", errors="replace")
    result["symbols"].append({"name": name, "address": hex(info.address),
                              "rva": hex(info.address - info.module_base),
                              "size": info.symbol_size})
    return True


try:
    stack = json.loads((args.output.parent / "dx11-rgb-stalled-threads.json").read_text())
    engine_address = next(int(frame["address"], 16) for thread in stack["threads"]
                          for frame in thread["frames"]
                          if frame.get("module") == "CarlaUE4-Win64-Shipping.exe")
    base = d.SymGetModuleBase64(process, engine_address)
    if not d.SymEnumSymbols(process, base, b"*FPixelReader*", callback, None):
        result["enumeration_error"] = C.get_last_error()
    if args.address:
        line = SourceLine()
        line.size = C.sizeof(line)
        displacement = W.DWORD()
        if d.SymGetLineFromAddr64(process, args.address, C.byref(displacement), C.byref(line)):
            result["source"] = {"file": line.file.decode("utf-8", errors="replace"),
                                "line": line.line, "displacement": displacement.value}
        else:
            result["source_error"] = C.get_last_error()
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2), flush=True)
finally:
    d.SymCleanup(process)
    k.CloseHandle(process)
